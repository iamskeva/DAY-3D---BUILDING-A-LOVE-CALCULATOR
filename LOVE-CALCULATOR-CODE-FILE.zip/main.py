# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#You are going to write a program that tests the compatibility between two people.

#Write your code below this line 👇

combinedName = name1 + name2
lowerCase = combinedName.lower()

t = lowerCase.count("t")
r = lowerCase.count("r") 
u = lowerCase.count("u") 
e = lowerCase.count("e")

true = t + r + u + e

l = lowerCase.count("l")
o = lowerCase.count("0") 
v = lowerCase.count("v") 
e = lowerCase.count("e")

love = l + o + v + e

loveScore = str(true) + str(love)

finalScore = int(loveScore)

if (finalScore < 10) or (finalScore  > 90):
  print(f"Your love score is {loveScore}, you two go together like coke and mentos.")

elif (finalScore) >= 40 and (finalScore) <= 50:
  print(f"Your love score is {loveScore}, you're alright together.")

else:
  print(f"Your love score is {loveScore}.")

